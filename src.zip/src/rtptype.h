#ifndef __RTPTYPES_H_
#define	__RTPTYPES_H_
#include <iostream>

typedef char*			_ptr;
typedef std::size_t		_len;

#endif // !__RTPTYPES_H_

